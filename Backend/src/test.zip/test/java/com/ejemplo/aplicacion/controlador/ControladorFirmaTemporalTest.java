package com.ejemplo.aplicacion.controlador;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class ControladorFirmaTemporalTest {

    @Test
    public void contextoCargaCorrectamente() {
        // Esto solo prueba que el contexto Spring arranca sin errores
    }
}
