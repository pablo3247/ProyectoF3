package com.ejemplo.aplicacion.modelo;

public class FirmaTemporal {
    private Long contratoId;
    private String datosFirma;

    public Long getContratoId() {
        return contratoId;
    }

    public void setContratoId(Long contratoId) {
        this.contratoId = contratoId;
    }

    public String getDatosFirma() {
        return datosFirma;
    }

    public void setDatosFirma(String datosFirma) {
        this.datosFirma = datosFirma;
    }
}
