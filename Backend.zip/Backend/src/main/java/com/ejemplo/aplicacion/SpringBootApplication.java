package com.ejemplo.aplicacion;

public @interface SpringBootApplication {
}
